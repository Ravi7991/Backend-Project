package supplychain.service;

import supplychain.entity.Location;

public interface LocationService extends BaseService<Location> {

}
