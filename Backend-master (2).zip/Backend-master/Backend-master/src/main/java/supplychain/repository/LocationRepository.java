package supplychain.repository;

//@Repository
public interface LocationRepository {

}
